import fs from 'node:fs';
import path from 'node:path';
import {gzipSync} from 'node:zlib';
import {build} from 'esbuild';
import {createRequire} from 'node:module';
const root=path.dirname(new URL(import.meta.url).pathname.replace(/^\/(\w:)/,'$1'));
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
let licenses='FORM / 造物 — open-source notices\nBuild: 2026-10-16\n\n';
for(const pkg of ['react','react-dom','three','three-mesh-bvh','xlsx','fflate','lucide-react']){const dir=path.join(root,'node_modules',pkg);const name=fs.readdirSync(dir).find(n=>/^license(\.txt|\.md)?$/i.test(n));licenses+='\n\n===== '+pkg+' =====\n'+(name?fs.readFileSync(path.join(dir,name),'utf8'):'See package repository for license.');}
licenses+='\n\n===== CAD engine =====\nSource: https://github.com/kovacsv/occt-import-js\nOpenCascade source: https://github.com/Open-Cascade-SAS/OCCT\nEmbedded unmodified runtime with application worker glue.\n'+read('node_modules/occt-import-js/dist/license.occt-import-js.txt')+'\n'+read('node_modules/occt-import-js/dist/license.occt.txt');
const worker=read('node_modules/occt-import-js/dist/occt-import-js.js')+'\n'+read('src/cad-worker.js');
const wasm=gzipSync(fs.readFileSync(path.join(root,'node_modules/occt-import-js/dist/occt-import-js.wasm')),{level:9}).toString('base64');
const require=createRequire(import.meta.url);
const browserEntries={'three':'three/build/three.module.js','three-mesh-bvh':'three-mesh-bvh/src/index.js','fflate':'fflate/esm/browser.js','xlsx':'xlsx/xlsx.mjs','lucide-react':'lucide-react/dist/esm/lucide-react.mjs'};
const fsPlugin={name:'workspace-files',setup(b){b.onResolve({filter:/.*/},args=>{let target;if(args.path.startsWith('.')||path.isAbsolute(args.path))target=path.resolve(args.resolveDir||root,args.path);else if(browserEntries[args.path])target=path.join(root,'node_modules',browserEntries[args.path]);else target=require.resolve(args.path);return {path:target,namespace:'workspace'};});b.onLoad({filter:/.*/,namespace:'workspace'},args=>({contents:fs.readFileSync(args.path,'utf8'),loader:args.path.endsWith('.css')?'css':args.path.endsWith('.jsx')?'jsx':'js',resolveDir:path.dirname(args.path)}));}};
const result=await build({absWorkingDir:root,entryPoints:['./src/App.jsx'],plugins:[fsPlugin],tsconfigRaw:{},bundle:true,minify:true,write:false,format:'iife',target:['chrome110','edge110'],platform:'browser',jsx:'automatic',outfile:'app.js',legalComments:'inline',define:{'process.env.NODE_ENV':'"production"',__CAD_WORKER__:JSON.stringify(worker),__CAD_WASM__:JSON.stringify(wasm),__LICENSES__:JSON.stringify(licenses)}});
const js=result.outputFiles.find(f=>f.path.endsWith('.js')).text.replace(/<\/script/gi,'<\\/script');const css=result.outputFiles.find(f=>f.path.endsWith('.css')).text;
const html=`<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval' blob:; style-src 'unsafe-inline'; img-src data: blob:; worker-src blob:; connect-src 'none'; font-src data:; object-src 'none'; base-uri 'none'"><title>FORM / 造物 · 3D 打印报价工作台</title><style>${css}</style></head><body><div id="root"></div><noscript>请启用 JavaScript，并使用最新版 Edge 或 Chrome 打开此文件。</noscript><script>${js}</script></body></html>`;
const output=path.join(root,'index.html');fs.mkdirSync(path.dirname(output),{recursive:true});fs.writeFileSync(output,html,'utf8');fs.writeFileSync(path.join(root,'THIRD_PARTY_NOTICES.txt'),licenses);console.log(JSON.stringify({output,bytes:fs.statSync(output).size,wasmGzip:wasm.length},null,2));
