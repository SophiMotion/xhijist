import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { meshMetrics, sampleThickness } from '../src/geometry.mjs';
import { quotePart, quoteProject, defaultSettings, materials, validateSettings, risksForPart } from '../src/domain.mjs';

test('10 mm cube has 1 cm³ volume and 6 cm² area even far from origin',()=>{
 const g = new THREE.BoxGeometry(10,10,10).toNonIndexed();g.translate(12000,-20000,9000);
 const m=meshMetrics(g);assert.equal(m.closed,true);assert.ok(Math.abs(m.volume-1)<1e-6);assert.ok(Math.abs(m.area-6)<1e-6);assert.deepEqual(m.size,[10,10,10]);
});
test('open surface is not treated as quotable volume',()=>{
 const m=meshMetrics(new THREE.PlaneGeometry(10,10).toNonIndexed());assert.equal(m.closed,false);assert.equal(m.volume,null);assert.ok(m.boundaryEdges>0);
});
test('cube wall ray samples measure 10 mm',()=>{
 const g=new THREE.BoxGeometry(10,10,10).toNonIndexed();const result=sampleThickness(g,100);assert.ok(Math.abs(result.minimum-10)<0.01);assert.ok(result.coverage>.9);
});
test('quote includes quantity, markup, discount and tax exactly once',()=>{
 const settings=structuredClone(defaultSettings);settings.markup=20;settings.discount=10;settings.tax=13;settings.minimum=0;
 const part={material:'aluminum',process:'SLM',finish:'none',qty:3,metrics:{volume:2,closed:true},density:2.7,materialRate:1,processRate:2,setupFee:5,finishFee:0};
 const q=quotePart(part,settings);assert.equal(q.base,14.4);assert.equal(q.subtotal,43.2);
 const total=quoteProject([part],settings);assert.equal(total.discount,5.18);assert.equal(total.tax,6.07);assert.equal(total.total,52.73);
});
test('unreliable volume is excluded and flagged',()=>{
 const p={material:'aluminum',process:'SLM',finish:'none',qty:1,metrics:{volume:null,closed:false}};
 assert.equal(quotePart(p,defaultSettings).valid,false);assert.equal(quoteProject([p],defaultSettings).excluded,1);
 assert.ok(risksForPart(p,defaultSettings).some(r=>r.severity==='high'));
});
test('invalid values are rejected, zero tax and markup are valid',()=>{
 assert.equal(validateSettings({...defaultSettings,tax:0,markup:0}).length,0);
 assert.ok(validateSettings({...defaultSettings,discount:101}).length>0);
 assert.ok(validateSettings({...defaultSettings,tax:NaN}).length>0);
});
