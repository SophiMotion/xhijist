import http from 'node:http';
import fs from 'node:fs';
const file=new URL('./index.html',import.meta.url);
http.createServer((req,res)=>{
  if(req.url==='/favicon.ico'){res.writeHead(204);res.end();return;}
  res.setHeader('Content-Type','text/html; charset=utf-8');
  res.end(fs.readFileSync(file));
}).listen(4173,'127.0.0.1',()=>console.log('FORM preview: http://127.0.0.1:4173'));
