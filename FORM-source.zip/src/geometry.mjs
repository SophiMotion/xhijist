import * as THREE from 'three';
import { MeshBVH } from 'three-mesh-bvh';
export function cleanGeometry(source){
 const g=source.index?source.toNonIndexed():source.clone();
 for(const key of Object.keys(g.attributes))if(key!=='position')g.deleteAttribute(key);
 const a=g.attributes.position?.array;if(!a||a.length<9||a.length%9)throw new Error('模型中没有有效的三角形表面');
 if(a.length/9>500000)throw new Error('单个零件超过 50 万三角面，请降低导出精度后重试');
 for(const n of a)if(!Number.isFinite(n))throw new Error('模型包含无效坐标');
 g.clearGroups();g.computeVertexNormals();g.computeBoundingBox();return g;
}
export function meshMetrics(geometry){
 const g=geometry.index?geometry.toNonIndexed():geometry;g.computeBoundingBox();const box=g.boundingBox;
 const center=box.getCenter(new THREE.Vector3());const size=box.getSize(new THREE.Vector3()).toArray();const pos=g.attributes.position;const edgeMap=new Map(),vertexMap=new Map();const tolerance=Math.max(1e-6,Math.max(...size)*1e-7);
 const ids=new Array(pos.count);let serial=0;for(let i=0;i<pos.count;i++){const k=[pos.getX(i),pos.getY(i),pos.getZ(i)].map(v=>Math.round(v/tolerance)).join(',');if(!vertexMap.has(k))vertexMap.set(k,serial++);ids[i]=vertexMap.get(k);}
 let volume=0,area=0,degenerate=0;const a=new THREE.Vector3(),b=new THREE.Vector3(),c=new THREE.Vector3(),cross=new THREE.Vector3(),ab=new THREE.Vector3(),ac=new THREE.Vector3();
 for(let i=0;i<pos.count;i+=3){a.fromBufferAttribute(pos,i).sub(center);b.fromBufferAttribute(pos,i+1).sub(center);c.fromBufferAttribute(pos,i+2).sub(center);cross.crossVectors(b,c);volume+=a.dot(cross)/6;ab.subVectors(b,a);ac.subVectors(c,a);const triangleArea=cross.crossVectors(ab,ac).length()/2;area+=triangleArea;if(triangleArea<tolerance*tolerance)degenerate++;
  for(const [u,v] of [[ids[i],ids[i+1]],[ids[i+1],ids[i+2]],[ids[i+2],ids[i]]]){if(u===v)continue;const key=u<v?`${u},${v}`:`${v},${u}`;const edge=edgeMap.get(key)||{count:0,balance:0};edge.count++;edge.balance+=u<v?1:-1;edgeMap.set(key,edge);}
 }
 let boundaryEdges=0,nonManifoldEdges=0,inconsistentEdges=0;for(const e of edgeMap.values()){if(e.count===1)boundaryEdges++;else if(e.count!==2)nonManifoldEdges++;else if(e.balance!==0)inconsistentEdges++;}
 const closed=boundaryEdges===0&&nonManifoldEdges===0&&inconsistentEdges===0&&Math.abs(volume)>1e-8&&degenerate===0;
 return {volume:closed?Math.abs(volume)/1000:null,signedVolume:volume,area:area/100,size,triangles:pos.count/3,vertices:vertexMap.size,boundaryEdges,nonManifoldEdges,inconsistentEdges,degenerate,closed};
}
export function sampleThickness(source,maxSamples=900){
 const g=cleanGeometry(source);const metrics=meshMetrics(g);if(!metrics.closed)throw new Error('请先修复网格，壁厚分析需要封闭且面向一致的表面');
 const pos=g.attributes.position;const count=pos.count/3;const n=Math.min(count,maxSamples);const bvh=new MeshBVH(g,{targetLeafSize:8});const result=[];const locations=[];const a=new THREE.Vector3(),b=new THREE.Vector3(),c=new THREE.Vector3(),normal=new THREE.Vector3(),center=new THREE.Vector3(),ab=new THREE.Vector3(),ac=new THREE.Vector3();const ray=new THREE.Ray();const eps=Math.max(...metrics.size)*1e-6;const orientation=metrics.signedVolume<0?-1:1;
 for(let j=0;j<n;j++){const index=Math.floor(j*count/n)*3;a.fromBufferAttribute(pos,index);b.fromBufferAttribute(pos,index+1);c.fromBufferAttribute(pos,index+2);normal.crossVectors(ab.subVectors(b,a),ac.subVectors(c,a)).normalize().multiplyScalar(-orientation);center.copy(a).add(b).add(c).multiplyScalar(1/3);ray.origin.copy(center).addScaledVector(normal,eps);ray.direction.copy(normal);const hit=bvh.raycastFirst(ray,THREE.DoubleSide,eps,Infinity);if(hit&&hit.distance>eps){result.push(hit.distance+eps);locations.push({point:center.toArray(),value:hit.distance+eps});}}
 result.sort((a,b)=>a-b);g.dispose();return {minimum:result[0]??null,median:result[Math.floor(result.length/2)]??null,maximum:result.at(-1)??null,coverage:result.length/n,samples:n,hits:result.length,locations};
}
