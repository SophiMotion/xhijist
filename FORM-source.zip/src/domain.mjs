export const materials=[
 {id:'aluminum',name:'铝合金 AlSi10Mg',density:2.67,rate:.38,processes:['SLM'],color:'#c97945'},
 {id:'steel',name:'不锈钢 316L',density:7.98,rate:.48,processes:['SLM'],color:'#a9b6c3'},
 {id:'titanium',name:'钛合金 TC4',density:4.43,rate:1.65,processes:['SLM'],color:'#91949b'},
 {id:'resin',name:'标准光敏树脂',density:1.12,rate:.12,processes:['SLA'],color:'#e4e7df'},
 {id:'tough',name:'韧性光敏树脂',density:1.15,rate:.22,processes:['SLA'],color:'#75a9b2'},
 {id:'nylon',name:'尼龙 PA12',density:1.01,rate:.27,processes:['SLS','MJF'],color:'#d7d7cc'},
 {id:'pla',name:'PLA',density:1.24,rate:.06,processes:['FDM'],color:'#6ba998'},
 {id:'abs',name:'ABS',density:1.04,rate:.07,processes:['FDM'],color:'#d9b86c'},
 {id:'petg',name:'PETG',density:1.27,rate:.08,processes:['FDM'],color:'#85a6d0'}
];
export const processes={SLM:{name:'SLM 金属激光熔融',rate:4.8,setup:18,wall:.8},SLA:{name:'SLA 光固化',rate:.9,setup:8,wall:.8},SLS:{name:'SLS 激光烧结',rate:1.5,setup:12,wall:1},MJF:{name:'MJF 多射流熔融',rate:1.6,setup:12,wall:1},FDM:{name:'FDM 熔融沉积',rate:.65,setup:5,wall:1.2}};
export const finishes={none:{name:'无后处理',fee:0},sandblast:{name:'喷砂',fee:8},polish:{name:'打磨抛光',fee:18},paint:{name:'喷漆',fee:25},anodize:{name:'阳极氧化',fee:20}};
export const defaultSettings={markup:20,discount:0,tax:13,minimum:0,wall:1,largeSize:250,slenderness:15,materialRates:Object.fromEntries(materials.map(m=>[m.id,m.rate])),processRates:Object.fromEntries(Object.entries(processes).map(([k,v])=>[k,v.rate])),setupFees:Object.fromEntries(Object.entries(processes).map(([k,v])=>[k,v.setup])),finishFees:Object.fromEntries(Object.entries(finishes).map(([k,v])=>[k,v.fee]))};
export const money=n=>new Intl.NumberFormat('zh-CN',{style:'currency',currency:'CNY'}).format(Number.isFinite(n)?n:0);
export const fmt=(n,d=2)=>Number.isFinite(n)?n.toLocaleString('zh-CN',{minimumFractionDigits:d,maximumFractionDigits:d}):'—';
export const round=n=>Math.round((n+Number.EPSILON)*100)/100;
export function validateSettings(s){
 const errors=[];for(const [key,max] of [['markup',1000],['discount',100],['tax',100],['minimum',1e9],['wall',1000],['largeSize',1e6],['slenderness',1e6]])if(!Number.isFinite(s[key])||s[key]<0||s[key]>max)errors.push(key);
 for(const key of ['materialRates','processRates','setupFees','finishFees'])for(const value of Object.values(s[key]||{}))if(!Number.isFinite(value)||value<0||value>1e9)errors.push(key);
 return errors;
}
export function quotePart(p,s){
 const m=materials.find(m=>m.id===p.material);const process=processes[p.process];const finish=finishes[p.finish];
 const density=p.density??m?.density,materialRate=p.materialRate??s.materialRates[p.material],processRate=p.processRate??s.processRates[p.process],setupFee=p.setupFee??s.setupFees[p.process],finishFee=p.finishFee??s.finishFees[p.finish];
 if(!m||!process||!finish||!m.processes.includes(p.process)||!p.metrics?.closed||!Number.isFinite(p.metrics.volume)||p.metrics.volume<=0||![density,materialRate,processRate,setupFee,finishFee].every(n=>Number.isFinite(n)&&n>=0)||density===0||!Number.isInteger(p.qty)||p.qty<1||p.qty>100000){return {valid:false,base:0,subtotal:0,weight:0,material:0,process:0,finish:0};}
 const weight=p.metrics.volume*density,material=weight*materialRate,processCost=p.metrics.volume*processRate+setupFee,finishCost=finishFee;
 const base=round(material+processCost+finishCost);
 return {valid:true,weight,material:material*p.qty,process:processCost*p.qty,finish:finishCost*p.qty,base,subtotal:round(base*p.qty)};
}
export function quoteProject(parts,s){
 const rows=parts.map(p=>quotePart(p,s));const base=round(rows.reduce((a,q)=>a+q.subtotal,0));const markup=round(base*s.markup/100);const discount=round((base+markup)*s.discount/100);const preMinimum=round(base+markup-discount);const adjustment=rows.some(q=>q.valid)?Math.max(0,round(s.minimum-preMinimum)):0;const net=round(preMinimum+adjustment);const tax=round(net*s.tax/100);return {rows,base,markup,discount,adjustment,net,tax,total:round(net+tax),weight:rows.reduce((a,q,i)=>a+q.weight*parts[i].qty,0),excluded:rows.filter(q=>!q.valid).length,material:rows.reduce((a,q)=>a+q.material,0),process:rows.reduce((a,q)=>a+q.process,0),finish:rows.reduce((a,q)=>a+q.finish,0)};
}
export function risksForPart(p,s){
 const risks=[];const m=p.metrics||{};const mat=materials.find(m=>m.id===p.material);
 const add=(severity,title,detail)=>risks.push({severity,title,detail});
 if(!m.closed)add('high','网格完整性需修复',`存在开放边、非流形边或不一致面向，自动体积报价已暂停。请在 CAD 中修复并重新导出。`);
 if(mat&&!mat.processes.includes(p.process))add('high','材质与工艺不匹配','请选择该材质支持的制造工艺。');
 const size=m.size||[];if(Math.max(...size)>s.largeSize)add('medium','超出建议成型尺寸',`最大边 ${fmt(Math.max(...size),1)} mm，当前阈值 ${s.largeSize} mm。请核对设备成型空间。`);
 if(size.length&&Math.min(...size)>0&&Math.max(...size)/Math.min(...size)>s.slenderness)add('medium','细长结构',`长宽比高于 ${s.slenderness}，建议复核摆放、支撑及变形风险。`);
 if(p.wall?.minimum!=null&&p.wall.minimum<s.wall)add('high','采样发现薄壁',`采样最小厚度 ${fmt(p.wall.minimum,2)} mm，低于 ${s.wall} mm 规则阈值。`);
 if(!p.wall)add('info','壁厚尚未采样','运行壁厚分析后再评估薄壁风险。');
 else if(p.wall.coverage<.5)add('medium','壁厚采样命中率较低','几何可能含开放面或复杂内腔，建议在原生 CAD 中复核。');
 if(p.process==='FDM')add('info','FDM 使用实体体积估算','当前按实体体积计价，实际用料受填充率、支撑和切片结果影响。');
 if(p.finish==='anodize'&&p.material!=='aluminum')add('medium','后处理需确认','当前阳极氧化参考方案针对铝合金，请确认材料适用性。');
 return risks;
}
