import * as THREE from 'three';
import { STLLoader } from 'three/examples/jsm/loaders/STLLoader.js';
import { OBJLoader } from 'three/examples/jsm/loaders/OBJLoader.js';
import { PLYLoader } from 'three/examples/jsm/loaders/PLYLoader.js';
import { ThreeMFLoader } from 'three/examples/jsm/loaders/3MFLoader.js';
import { makePart,palette } from './models.mjs';
import { unzipSync,strFromU8 } from 'fflate';
export const ACCEPT='.stl,.obj,.ply,.3mf,.step,.stp,.iges,.igs,.brep';
let cadWorker;
function readCAD(buffer,extension){
 return new Promise((resolve,reject)=>{
  if(!cadWorker){const url=URL.createObjectURL(new Blob([__CAD_WORKER__],{type:'text/javascript'}));cadWorker=new Worker(url);URL.revokeObjectURL(url);}
  const timer=setTimeout(()=>{cadWorker?.terminate();cadWorker=null;reject(new Error('解析超过 90 秒，建议简化装配体或降低几何复杂度后重试'));},90000);
  cadWorker.onmessage=e=>{clearTimeout(timer);if(e.data.error)reject(new Error(e.data.error));else resolve(e.data);};
  cadWorker.onerror=()=>{clearTimeout(timer);cadWorker?.terminate();cadWorker=null;reject(new Error('CAD 解析器无法处理该文件，请确认文件有效并尝试导出 STEP AP214'));};
  cadWorker.postMessage({buffer,extension,wasm:__CAD_WASM__},[buffer]);
 });
}
export async function importModel(file,unit=1){
 if(file.size>100*1024*1024)throw new Error('单文件大小上限为 100 MB，请拆分大装配体');
 if(!file.size)throw new Error('文件为空');
 const ext=file.name.split('.').pop().toLowerCase();const stem=file.name.replace(/\.[^.]+$/,'');const data=await file.arrayBuffer();const parts=[];
 let fileScale=unit;if(['step','stp','iges','igs'].includes(ext))fileScale=1;
 if(ext==='3mf'){let unpacked=0;const zip=unzipSync(new Uint8Array(data),{filter:entry=>{unpacked+=entry.originalSize;if(unpacked>150*1024*1024)throw new Error('3MF 解压后的数据超过 150 MB，请精简模型与贴图');return entry.name.toLowerCase().endsWith('.model');}});const path=Object.keys(zip).find(p=>/3dmodel\.model$/i.test(p))||Object.keys(zip).find(p=>p.toLowerCase().endsWith('.model'));if(!path)throw new Error('3MF 中缺少模型数据');const xml=new DOMParser().parseFromString(strFromU8(zip[path]),'application/xml');const units={micron:.001,millimeter:1,centimeter:10,meter:1000,inch:25.4,foot:304.8};const name=xml.documentElement.getAttribute('unit')||'millimeter';if(!(name in units))throw new Error('3MF 使用了无法识别的单位');fileScale=units[name];}
 const add=(geometry,name)=>{if(fileScale!==1)geometry.scale(fileScale,fileScale,fileScale);parts.push(makePart(geometry,name,ext.toUpperCase(),{color:palette[parts.length%palette.length],source:file.name}));};
 if(ext==='stl')add(new STLLoader().parse(data),stem);
 else if(ext==='ply')add(new PLYLoader().parse(data),stem);
 else if(ext==='obj'||ext==='3mf'){
  const group=ext==='obj'?new OBJLoader().parse(new TextDecoder().decode(data)):new ThreeMFLoader().parse(data);
  group.updateMatrixWorld(true);group.traverse(node=>{if(node.isMesh&&node.geometry?.attributes.position){const g=node.geometry.clone();g.applyMatrix4(node.matrixWorld);add(g,node.name||`${stem}${parts.length?` / ${parts.length+1}`:''}`);}});
 }else if(['step','stp','iges','igs','brep'].includes(ext)){
  const result=await readCAD(data,ext);if(!result.success||!result.meshes?.length)throw new Error('未能读取有效曲面，请确认文件完整并重新导出');
  for(const [i,mesh] of result.meshes.entries()){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(mesh.attributes.position.array,3));g.setIndex(mesh.index.array);add(g,mesh.name||`${stem}${result.meshes.length>1?` / ${i+1}`:''}`);}
 }else throw new Error('暂不直接读取此格式。SolidWorks / Fusion / URDF 等请先导出 STEP、STL 或 OBJ');
 if(!parts.length)throw new Error('没有找到可分析的三角形表面');
 if(parts.length>200)throw new Error('单次导入超过 200 个零件，请拆分装配体');
 return parts;
}
