import React,{useEffect,useState,useRef} from 'react';
import { X,Info } from 'lucide-react';
export function NumberField({value,onChange,min=0,max=1000000,step='any',suffix,label,className='',...props}){
 const [draft,setDraft]=useState(String(value)),[invalid,setInvalid]=useState(false);useEffect(()=>{setDraft(String(value));setInvalid(false);},[value]);
 function commit(){const n=Number(draft);if(draft.trim()===''||!Number.isFinite(n)||n<min||n>max||(step===1&&!Number.isInteger(n))){setInvalid(true);setDraft(String(value));return;}setInvalid(false);onChange(n);}
 return <span className={`number-field ${invalid?'invalid':''} ${className}`}><input {...props} type="number" value={draft} aria-label={label} title={invalid?`请输入 ${min} 至 ${max} 的有效数字`:label} min={min} max={max} step={step} onChange={e=>{setDraft(e.target.value);setInvalid(false);}} onBlur={commit} onKeyDown={e=>{if(e.key==='Enter')e.currentTarget.blur();}}/>{suffix&&<span>{suffix}</span>}</span>;
}
export function Modal({title,children,onClose,wide=false}){
 const ref=useRef();useEffect(()=>{const prev=document.activeElement;const old=document.body.style.overflow;document.body.style.overflow='hidden';const el=ref.current;el.querySelector('button,input,select,textarea')?.focus();function key(e){if(e.key==='Escape')onClose();if(e.key==='Tab'){const focusable=[...el.querySelectorAll('button,input,select,textarea,a[href]')].filter(x=>!x.disabled);const first=focusable[0],last=focusable.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}}document.addEventListener('keydown',key);return()=>{document.body.style.overflow=old;document.removeEventListener('keydown',key);prev?.focus();};},[]);
 return <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)onClose();}}><section ref={ref} className={`modal ${wide?'wide':''}`} role="dialog" aria-modal="true" aria-label={title}><header><h2>{title}</h2><button className="icon-button" aria-label="关闭弹窗" onClick={onClose}><X size={20}/></button></header><div className="modal-body">{children}</div></section></div>;
}
export function Note({children}){return <div className="note"><Info size={15}/><span>{children}</span></div>;}
