import * as XLSX from 'xlsx';
import * as THREE from 'three';
import {makePart} from './models.mjs';
import {materials,processes,finishes,defaultSettings,validateSettings,quoteProject,round,risksForPart} from './domain.mjs';
export function download(blob,name){const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download=name;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);}
export const safeName=name=>(name||'未命名项目').replace(/[<>:"/\\|?*\x00-\x1F]/g,'_').slice(0,100);
function toBase64(array){const bytes=new Uint8Array(array.buffer,array.byteOffset,array.byteLength);let s='';for(let i=0;i<bytes.length;i+=32768)s+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(s);}
export function serializeProject(project,parts,settings){return JSON.stringify({app:'FORM_PROJECT',version:1,project,settings,parts:parts.map(({geometry,metrics,wall,...p})=>({...p,positions:toBase64(geometry.attributes.position.array)}))});}
export function deserializeProject(text){
 const data=JSON.parse(text);if(data.app!=='FORM_PROJECT'||data.version!==1||!Array.isArray(data.parts)||data.parts.length>200)throw new Error('不是有效的 FORM 项目文件，或文件版本不受支持');
 const settings={...structuredClone(defaultSettings),...data.settings};
 for(const key of ['materialRates','processRates','setupFees','finishFees'])settings[key]={...defaultSettings[key],...data.settings?.[key]};
 if(validateSettings(settings).length)throw new Error('项目中的报价或风险参数无效');
 let bytes=0;const parts=data.parts.map(p=>{
  if(typeof p.positions!=='string'||p.positions.length>32000000)throw new Error('项目模型数据不完整或过大');
  const raw=atob(p.positions);bytes+=raw.length;if(bytes>80000000||raw.length%36)throw new Error('项目模型大小或三角形数据无效');
  const arr=Uint8Array.from(raw,c=>c.charCodeAt(0));const floats=new Float32Array(arr.buffer);
  if(!materials.some(m=>m.id===p.material)||!processes[p.process]||!finishes[p.finish]||!Number.isInteger(p.qty)||p.qty<1||p.qty>100000)throw new Error('项目包含无效的零件配置');
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(floats,3));
  const options={material:p.material,process:p.process,finish:p.finish,qty:p.qty,color:/^#[0-9a-f]{6}$/i.test(p.color)?p.color:'#c97c48',visible:p.visible!==false,scale:typeof p.scale==='number'&&p.scale>0?p.scale:1};
  for(const key of ['density','materialRate','processRate','setupFee','finishFee'])if(p[key]!=null){if(!Number.isFinite(p[key])||p[key]<0||p[key]>1e9)throw new Error('项目含无效费用参数');options[key]=p[key];}
  return makePart(g,String(p.name||'未命名零件').slice(0,200),String(p.format||'MODEL').slice(0,15),options);
 });
 const project={name:String(data.project?.name||'未命名项目').slice(0,200),customer:String(data.project?.customer||'').slice(0,200),contact:String(data.project?.contact||'').slice(0,200),company:String(data.project?.company||'').slice(0,200),notes:String(data.project?.notes||'').slice(0,2000),demo:!!data.project?.demo};
 return {project,parts,settings};
}
export function makeWorkbook(project,parts,settings){
 const q=quoteProject(parts,settings);const rows=[['FORM / 造物 · 3D 打印参考报价'],['项目',project.name,'客户',project.customer],['报价方',project.company,'联系方式',project.contact],['日期',new Date().toLocaleDateString('zh-CN'),'计价单位','人民币 CNY'],['备注',project.notes],[],['序号','零件名称','文件格式','材质','制造工艺','后处理','体积 cm³','单件重量 g','数量','基础单价 ¥','基础小计 ¥','状态']];
 parts.forEach((p,i)=>{const item=q.rows[i];rows.push([i+1,p.name,p.format,materials.find(m=>m.id===p.material)?.name,p.process,finishes[p.finish].name,p.metrics.volume==null?'待修复':round(p.metrics.volume),item.valid?round(item.weight):'—',p.qty,item.valid?item.base:'—',item.valid?item.subtotal:'—',item.valid?'已计价':'未计价：请检查网格与配置']);});
 rows.push([],['基础费用',q.base],['管理与利润加价',q.markup,settings.markup+'%'],['折扣抵扣',q.discount,settings.discount+'%'],['最低订单补差',q.adjustment],['未税金额',q.net],['税额',q.tax,settings.tax+'%'],['含税合计',q.total],['未计价零件数',q.excluded],[],['估价说明','体积来自三角网格；预设费率为示例值。实际报价需复核。壁厚分析为射线采样，不能替代制造验收。']);
 const wb=XLSX.utils.book_new();const ws=XLSX.utils.aoa_to_sheet(rows);ws['!cols']=[{wch:8},{wch:28},{wch:12},{wch:22},{wch:12},{wch:14},{wch:16},{wch:16},{wch:8},{wch:16},{wch:16},{wch:38}];ws['!autofilter']={ref:`A7:L${7+parts.length}`};ws['!merges']=[{s:{r:0,c:0},e:{r:0,c:11}}];
 Object.entries(ws).forEach(([k,v])=>{if(!k.startsWith('!')&&v.t==='n')v.z='0.00';});XLSX.utils.book_append_sheet(wb,ws,'报价明细');
 const params=[['报价参数（参考值，可修改）'],['加价率 %',settings.markup],['折扣 %',settings.discount],['税率 %',settings.tax],['最低订单金额 ¥',settings.minimum],[],['材料','密度 g/cm³','单价 ¥/g'],...materials.map(m=>[m.name,m.density,settings.materialRates[m.id]]),[],['工艺','加工单价 ¥/cm³','单件准备费 ¥'],...Object.entries(processes).map(([k,v])=>[v.name,settings.processRates[k],settings.setupFees[k]]),[],['后处理','单件费用 ¥'],...Object.entries(finishes).map(([k,v])=>[v.name,settings.finishFees[k]]),[],['薄壁阈值 mm',settings.wall],['最大尺寸 mm',settings.largeSize],['细长比阈值',settings.slenderness]];
 const pws=XLSX.utils.aoa_to_sheet(params);pws['!cols']=[{wch:32},{wch:24},{wch:24}];XLSX.utils.book_append_sheet(wb,pws,'报价及风险参数');
 const riskRows=[['零件','级别','风险项','说明'],...parts.flatMap(p=>risksForPart(p,settings).map(r=>[p.name,r.severity==='high'?'高':r.severity==='medium'?'中':'提示',r.title,r.detail]))];const rws=XLSX.utils.aoa_to_sheet(riskRows);rws['!cols']=[{wch:28},{wch:10},{wch:30},{wch:90}];XLSX.utils.book_append_sheet(wb,rws,'风险记录');return wb;
}
export function exportExcel(project,parts,settings){const wb=makeWorkbook(project,parts,settings);download(new Blob([XLSX.write(wb,{bookType:'xlsx',type:'array'})],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}),safeName(project.name)+'-报价明细.xlsx');}
