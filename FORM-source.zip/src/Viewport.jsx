import React,{useEffect,useRef,useState} from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Box,Maximize,Scan,Layers3,RotateCcw,Upload,Move3D,Eye,Grid2X2 } from 'lucide-react';

export default function Viewport({parts,selected,onSelect,onImport,busy,wallMode,wallThreshold}){
 const host=useRef(null),api=useRef(null),selectionCallback=useRef(onSelect);selectionCallback.current=onSelect;
 const [wire,setWire]=useState(false),[explode,setExplode]=useState(false),[gridOn,setGrid]=useState(true),[failure,setFailure]=useState(''),[drag,setDrag]=useState(false);const sign=useRef('');
 useEffect(()=>{
  const container=host.current;let renderer;
  try{renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,preserveDrawingBuffer:true});}catch{setFailure('当前浏览器未启用 WebGL，请用最新版 Edge / Chrome 打开，并启用硬件加速。');return;}
  renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));renderer.setClearColor('#222d35');renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFShadowMap;container.appendChild(renderer.domElement);
  const scene=new THREE.Scene();const camera=new THREE.PerspectiveCamera(35,1,.1,100000);camera.up.set(0,0,1);camera.position.set(160,-220,180);const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.dampingFactor=.08;controls.minDistance=.1;
  const environment=new RoomEnvironment();const pmrem=new THREE.PMREMGenerator(renderer);const envMap=pmrem.fromScene(environment,.04);scene.environment=envMap.texture;environment.dispose();
  scene.add(new THREE.HemisphereLight('#e7f5ff','#596573',2));const key=new THREE.DirectionalLight('#fff0de',5);key.position.set(80,-60,180);key.castShadow=true;key.shadow.mapSize.set(2048,2048);key.shadow.normalBias=.03;scene.add(key);scene.add(key.target);const rim=new THREE.DirectionalLight('#bad8e9',2);rim.position.set(-100,100,70);scene.add(rim);
  const group=new THREE.Group();scene.add(group);const stage=new THREE.Group();scene.add(stage);const pickables=[];let radius=100,modelSize=new THREE.Vector3(100,100,100);let animation;
  function fit(){const rect=container.getBoundingClientRect();camera.aspect=rect.width/rect.height;const dir=new THREE.Vector3(1,-1.45,1.05).normalize();const right=new THREE.Vector3().crossVectors(camera.up,dir).normalize();const up=new THREE.Vector3().crossVectors(dir,right).normalize();const tanV=Math.tan(THREE.MathUtils.degToRad(camera.fov/2)),tanH=tanV*camera.aspect;let distance=0;for(const x of [-1,1])for(const y of [-1,1])for(const z of [-1,1]){const corner=new THREE.Vector3(x*modelSize.x/2,y*modelSize.y/2,z*modelSize.z/2);distance=Math.max(distance,corner.dot(dir)+Math.max(Math.abs(corner.dot(right))/tanH,Math.abs(corner.dot(up))/tanV));}distance*=1.18;camera.position.copy(dir.multiplyScalar(distance));camera.near=Math.max(radius/1000,.001);camera.far=radius*100;camera.updateProjectionMatrix();controls.target.set(0,0,0);controls.maxDistance=radius*30;controls.update();}
  const resize=new ResizeObserver(()=>{const {width,height}=container.getBoundingClientRect();if(!width||!height)return;renderer.setSize(width,height);camera.aspect=width/height;camera.updateProjectionMatrix();});resize.observe(container);
  let pointerStart={x:0,y:0};const down=e=>{pointerStart={x:e.clientX,y:e.clientY};};const up=e=>{if(Math.hypot(e.clientX-pointerStart.x,e.clientY-pointerStart.y)>5)return;const rect=renderer.domElement.getBoundingClientRect();const pointer=new THREE.Vector2((e.clientX-rect.left)/rect.width*2-1,-(e.clientY-rect.top)/rect.height*2+1);const ray=new THREE.Raycaster();ray.setFromCamera(pointer,camera);const hit=ray.intersectObjects(pickables,false).find(h=>h.object.visible);if(hit)selectionCallback.current(hit.object.userData.id);};renderer.domElement.addEventListener('pointerdown',down);renderer.domElement.addEventListener('pointerup',up);
  function animate(){animation=requestAnimationFrame(animate);controls.update();renderer.render(scene,camera);}animate();
  api.current={scene,group,stage,pickables,key,fit,setRadius:n=>{radius=n;},setSize:s=>{modelSize=s;},renderer};
  return ()=>{cancelAnimationFrame(animation);resize.disconnect();controls.dispose();renderer.domElement.removeEventListener('pointerdown',down);renderer.domElement.removeEventListener('pointerup',up);scene.traverse(o=>{if(o.userData.ownedGeometry)o.geometry?.dispose();if(o.material){(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>m.dispose());}});envMap.dispose();pmrem.dispose();renderer.dispose();container.removeChild(renderer.domElement);api.current=null;};
 },[]);
 useEffect(()=>{
  const a=api.current;if(!a)return;
  for(const parent of [a.group,a.stage]){parent.traverse(o=>{if(o.userData.ownedGeometry)o.geometry?.dispose();if(o.material)(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>m.dispose());});parent.clear();}a.pickables.length=0;
  const box=new THREE.Box3();for(const p of parts)box.union(p.geometry.boundingBox||new THREE.Box3().setFromBufferAttribute(p.geometry.attributes.position));
  const center=parts.length?box.getCenter(new THREE.Vector3()):new THREE.Vector3();const size=parts.length?box.getSize(new THREE.Vector3()):new THREE.Vector3(100,100,100);const radius=Math.max(size.length()/2,1);a.setRadius(radius);a.setSize(size.clone().add(new THREE.Vector3(0,0,explode?Math.max(parts.length-1,0)*radius*.48:0)));a.group.position.copy(center).negate();
  parts.forEach((p,index)=>{
   const material=new THREE.MeshPhysicalMaterial({color:p.color,metalness:.7,roughness:.3,clearcoat:.18,wireframe:wire,side:THREE.DoubleSide,emissive:p.id===selected?'#0a332b':'#000000',emissiveIntensity:.12});
   const mesh=new THREE.Mesh(p.geometry,material);mesh.userData.id=p.id;mesh.visible=p.visible;mesh.castShadow=true;mesh.receiveShadow=true;
   if(explode){mesh.position.z=(index-(parts.length-1)/2)*radius*.48;mesh.position.x=parts.length>8?(index%4-1.5)*radius*.25:0;}
   a.group.add(mesh);a.pickables.push(mesh);
   if(p.id===selected&&!wire&&p.metrics.triangles<150000){const edges=new THREE.LineSegments(new THREE.EdgesGeometry(p.geometry,40),new THREE.LineBasicMaterial({color:'#e9b78f',transparent:true,opacity:.2}));edges.userData.ownedGeometry=true;mesh.add(edges);}
   if(wallMode&&p.id===selected&&p.wall?.locations?.length){const coordinates=[],colors=[];p.wall.locations.forEach(sample=>{coordinates.push(...sample.point);const color=new THREE.Color(sample.value<wallThreshold?'#ff735d':sample.value<wallThreshold*2?'#edc36c':'#40c8b5');colors.push(color.r,color.g,color.b);});const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(coordinates,3));geo.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));const points=new THREE.Points(geo,new THREE.PointsMaterial({size:Math.max(radius*.018,.15),vertexColors:true,depthTest:false}));points.userData.ownedGeometry=true;mesh.add(points);}
  });
  const floorZ=parts.length?box.min.z-center.z-radius*.06:-50;const grid=new THREE.GridHelper(radius*5,40,'#50616c','#384750');grid.rotation.x=Math.PI/2;grid.position.z=floorZ;grid.visible=gridOn;grid.material.transparent=true;grid.material.opacity=.45;grid.userData.ownedGeometry=true;a.stage.add(grid);
  const plane=new THREE.Mesh(new THREE.PlaneGeometry(radius*8,radius*8),new THREE.ShadowMaterial({color:'#000000',opacity:.22}));plane.userData.ownedGeometry=true;plane.position.z=floorZ-.1;plane.receiveShadow=true;a.stage.add(plane);
  a.key.position.set(radius,-radius,radius*3);a.key.shadow.camera.left=-radius*2;a.key.shadow.camera.right=radius*2;a.key.shadow.camera.top=radius*2;a.key.shadow.camera.bottom=-radius*2;a.key.shadow.camera.near=.1;a.key.shadow.camera.far=radius*8;a.key.shadow.camera.updateProjectionMatrix();
  const newSign=parts.map(p=>p.id+p.geometry.uuid).join('|');if(sign.current!==newSign){sign.current=newSign;a.fit();}
 },[parts,selected,wire,explode,gridOn,wallMode,wallThreshold]);
 function fullscreen(){const el=host.current.parentElement;if(document.fullscreenElement)document.exitFullscreen?.();else el.requestFullscreen?.().catch(()=>{});}
 return <section className={`viewport ${drag?'dragging':''}`} aria-label="三维模型预览" onDragOver={e=>{e.preventDefault();setDrag(true);}} onDragLeave={e=>{if(!e.currentTarget.contains(e.relatedTarget))setDrag(false);}} onDrop={e=>{e.preventDefault();setDrag(false);if(!busy)onImport(e.dataTransfer.files);}}>
  <div ref={host} className="canvas-host" />
  <div className="viewport-heading"><span><Box size={17}/>三维预览</span><span className="view-label">透视视图</span></div>
  <div className="viewport-tools">
   <button title="适配视图" aria-label="适配视图" onClick={()=>api.current?.fit()}><Scan size={17}/></button>
   <button title="线框模式" aria-label="线框模式" aria-pressed={wire} className={wire?'active':''} onClick={()=>setWire(!wire)}><Box size={17}/></button>
   <button title="爆炸视图" aria-label="爆炸视图" aria-pressed={explode} className={explode?'active':''} onClick={()=>{setExplode(!explode);}}><Layers3 size={17}/></button>
   <button title="显示网格" aria-label="显示网格" aria-pressed={gridOn} className={gridOn?'active':''} onClick={()=>setGrid(!gridOn)}><Grid2X2 size={17}/></button>
   <button title="全屏预览" aria-label="全屏预览" onClick={fullscreen}><Maximize size={17}/></button>
  </div>
  {(!parts.length||failure)&&<div className="canvas-empty"><Box size={44}/><h2>{failure?'三维预览不可用':'从一个模型开始'}</h2><p>{failure||'拖入模型，查看几何与制造报价'}</p>{!failure&&<button className="button primary" onClick={()=>document.getElementById('models-input').click()}><Upload size={16}/>选择模型文件</button>}</div>}
  <div className="axis-widget" aria-hidden="true"><span className="axis-z">Z</span><span className="axis-x">X</span><span className="axis-y">Y</span><i/><b/><em/></div>
  <div className="viewport-footer"><span><Move3D size={14}/>拖动旋转 · 右键平移 · 滚轮缩放</span><span>{parts.length?parts.reduce((sum,p)=>sum+p.metrics.triangles,0).toLocaleString()+' 个三角面':'STL / OBJ / 3MF / STEP / IGES'}</span></div>
  {drag&&<div className="drop-overlay"><Upload size={36}/><strong>松开以导入模型</strong><span>支持多个零件与装配体</span></div>}
  {busy&&<div className="busy-overlay"><span className="spinner"/><strong>{busy}</strong><span>模型仅在本机处理</span></div>}
 </section>;
}
