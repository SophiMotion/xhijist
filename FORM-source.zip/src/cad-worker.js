let enginePromise;
self.onmessage=async event=>{
 try{
  const {buffer,extension,wasm}=event.data;
  if(!enginePromise){const raw=atob(wasm);const bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);enginePromise=(async()=>{const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));const wasmBinary=new Uint8Array(await new Response(stream).arrayBuffer());return occtimportjs({wasmBinary,print:()=>{},printErr:()=>{}});})();}
  const engine=await enginePromise;
  const method=['step','stp'].includes(extension)?'ReadStepFile':['igs','iges'].includes(extension)?'ReadIgesFile':'ReadBrepFile';
  const result=engine[method](new Uint8Array(buffer),{linearUnit:'millimeter',linearDeflectionType:'absolute_value',linearDeflection:.04,angularDeflection:.2});
  self.postMessage(result);
 }catch(error){self.postMessage({error:'CAD 解析失败：'+(error?.message||'文件格式或几何结构无法读取')});}
};
