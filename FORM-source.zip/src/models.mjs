import * as THREE from 'three';
import { cleanGeometry,meshMetrics } from './geometry.mjs';
export const palette=['#c97c48','#95a8b4','#668f8b','#a8a0bc','#c3ae79','#6e9bb2'];
let serial=0;
export function makePart(source,name,format='STL',options={}){
 const geometry=cleanGeometry(source);const metrics=meshMetrics(geometry);
 return {id:`part-${Date.now()}-${serial++}`,name,format,geometry,metrics,material:'aluminum',process:'SLM',finish:'sandblast',qty:1,color:palette[serial%palette.length],visible:true,scale:1,...options};
}
function circle(r,x=0,y=0){const p=new THREE.Path();p.absarc(x,y,r,0,Math.PI*2,true);return p;}
function plate(radius,depth,holes){const shape=new THREE.Shape();shape.absarc(0,0,radius,0,Math.PI*2,false);shape.holes.push(circle(13));for(let i=0;i<6;i++){const a=i*Math.PI/3;shape.holes.push(circle(holes,Math.cos(a)*(radius-9),Math.sin(a)*(radius-9)));}return new THREE.ExtrudeGeometry(shape,{depth,bevelEnabled:false,curveSegments:40});}
export function demoParts(){
 const flange=plate(46,9,4);flange.translate(0,0,15);
 const sleeve=new THREE.LatheGeometry([new THREE.Vector2(13,0),new THREE.Vector2(24,0),new THREE.Vector2(24,4),new THREE.Vector2(20,7),new THREE.Vector2(20,32),new THREE.Vector2(18,34),new THREE.Vector2(13,34),new THREE.Vector2(13,0)],96);sleeve.rotateX(Math.PI/2);sleeve.translate(0,0,31);
 const base=plate(49,8,4);base.translate(0,0,-6);
 return [makePart(flange,'连接法兰','DEMO',{color:palette[0],qty:2}),makePart(sleeve,'定位套筒','DEMO',{color:'#c98a56'}),makePart(base,'安装底座','DEMO',{color:'#8995a2',material:'steel'})];
}
export function scaledPart(part,factor){
 if(!Number.isFinite(factor)||factor<=0||factor>10000)throw new Error('请输入有效的模型比例');
 const geometry=part.geometry.clone();geometry.scale(factor,factor,factor);return {...part,geometry,metrics:meshMetrics(geometry),scale:part.scale*factor,wall:null};
}
